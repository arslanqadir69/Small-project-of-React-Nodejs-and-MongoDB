import React from 'react';
import {Signup} from './component/signup';
import './App.css';

function App() {
  return (
  
    <Signup/>
  );
}

export default App;
